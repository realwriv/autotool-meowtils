package meowtils.extension;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import wtf.tatp.meowtils.config.Config;
import wtf.tatp.meowtils.event.ClientTickEvent;
import wtf.tatp.meowtils.event.api.EventTarget;
import wtf.tatp.meowtils.extension.Extension;
import wtf.tatp.meowtils.gui.values.ExpandValue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.BooleanSupplier;

/**
 * AutoTool - while you hold left click on a block, swaps to the best TOOL in your hotbar
 * (pickaxe, axe, shovel, shears) and optionally swaps back afterwards.
 *
 * Swords, hoes and every other item are never selected.
 */
public class AutoTool extends Extension {

    /* ------------------------------------------------------------------ */
    /* Required by Meowtils                                                */
    /* ------------------------------------------------------------------ */

    @Config public boolean enabled = false;
    @Config public int key = 0;

    /* ------------------------------------------------------------------ */
    /* Timing                                                              */
    /* ------------------------------------------------------------------ */

    /** Milliseconds to wait after targeting a block before swapping to the tool. */
    @Config public int swapDelay = 0;
    /** Swap back to the original slot once you stop mining. */
    @Config public boolean swapBack = true;
    /** Milliseconds to wait after you stop mining before swapping back. */
    @Config public int swapBackDelay = 250;

    /* ------------------------------------------------------------------ */
    /* Conditions                                                          */
    /* ------------------------------------------------------------------ */

    private static final String SNEAK_ALWAYS = "Always";
    private static final String SNEAK_ONLY = "Only sneaking";
    private static final String SNEAK_NOT = "Not sneaking";

    @Config public String sneakMode = SNEAK_ALWAYS;
    @Config public boolean onGroundOnly = false;

    /* ------------------------------------------------------------------ */
    /* Tool types                                                          */
    /* ------------------------------------------------------------------ */

    @Config public boolean toolPickaxe = true;
    @Config public boolean toolAxe = true;
    @Config public boolean toolShovel = true;
    @Config public boolean toolShears = true;

    /* ------------------------------------------------------------------ */
    /* Block whitelist                                                     */
    /* ------------------------------------------------------------------ */

    @Config public boolean whitelistEnabled = false;
    /** Extra block names, comma separated, e.g. "ender_chest, hay_block". */
    @Config public String whitelistExtra = "";

    @Config public boolean wlStone = true;
    @Config public boolean wlOres = true;
    @Config public boolean wlObsidian = false;
    @Config public boolean wlNetherrack = false;
    @Config public boolean wlSandstone = false;
    @Config public boolean wlDirt = false;
    @Config public boolean wlSand = false;
    @Config public boolean wlSnowIce = false;
    @Config public boolean wlLogs = true;
    @Config public boolean wlWood = false;
    @Config public boolean wlLeaves = false;
    @Config public boolean wlWool = false;
    @Config public boolean wlCobweb = false;
    @Config public boolean wlMetal = false;

    /** Registry name (without "minecraft:") -> is its whitelist group currently checked. */
    private final Map<String, BooleanSupplier> groupLookup = new HashMap<String, BooleanSupplier>();

    private String cachedExtraRaw = null;
    private Set<String> cachedExtra = new HashSet<String>();

    /* ------------------------------------------------------------------ */
    /* Runtime state                                                       */
    /* ------------------------------------------------------------------ */

    /** Slot we were holding before the first swap, -1 when nothing is swapped. */
    private int originalSlot = -1;
    /** Slot we swapped to, used to notice when the player changes slot manually. */
    private int swappedSlot = -1;
    /** When we first wanted to swap (0 = not waiting). */
    private long targetSince = 0L;
    /** When mining stopped (0 = not waiting). */
    private long idleSince = 0L;

    public AutoTool() {
        super("AutoTool", "Meowtils");

        tooltip("Swaps to the best tool (pickaxe, axe, shovel, shears) while mining.");

        // --- Timing ---
        slider("Swap delay", 0, 500, 50, "ms", "swapDelay", int.class);
        toggle("Swap back", "swapBack");
        slider("Swap back delay", 0, 1000, 50, "ms", "swapBackDelay", int.class);

        // --- Conditions ---
        mode("Sneak", Arrays.asList(SNEAK_ALWAYS, SNEAK_ONLY, SNEAK_NOT), "sneakMode");
        toggle("Only on ground", "onGroundOnly");

        // --- Tools ---
        expand("Tools", e -> {
            e.check("Pickaxe", "toolPickaxe");
            e.check("Axe", "toolAxe");
            e.check("Shovel", "toolShovel");
            e.check("Shears", "toolShears");
        });

        // --- Whitelist ---
        toggle("Use whitelist", "whitelistEnabled");
        expand("Whitelist", e -> {
            group(e, "Stone", "wlStone", () -> wlStone,
                    "stone", "cobblestone", "mossy_cobblestone", "stonebrick",
                    "stone_slab", "stone_slab2", "double_stone_slab", "double_stone_slab2",
                    "stone_stairs", "stone_brick_stairs");
            group(e, "Ores", "wlOres", () -> wlOres,
                    "coal_ore", "iron_ore", "gold_ore", "diamond_ore", "emerald_ore",
                    "lapis_ore", "redstone_ore", "lit_redstone_ore", "quartz_ore");
            group(e, "Obsidian", "wlObsidian", () -> wlObsidian,
                    "obsidian");
            group(e, "Netherrack", "wlNetherrack", () -> wlNetherrack,
                    "netherrack");
            group(e, "Sandstone & Clay", "wlSandstone", () -> wlSandstone,
                    "sandstone", "red_sandstone", "hardened_clay", "stained_hardened_clay");
            group(e, "Dirt & Grass", "wlDirt", () -> wlDirt,
                    "dirt", "grass", "mycelium", "farmland", "clay");
            group(e, "Sand & Gravel", "wlSand", () -> wlSand,
                    "sand", "gravel", "soul_sand");
            group(e, "Snow & Ice", "wlSnowIce", () -> wlSnowIce,
                    "snow", "snow_layer", "ice", "packed_ice");
            group(e, "Logs", "wlLogs", () -> wlLogs,
                    "log", "log2");
            group(e, "Planks & Wooden", "wlWood", () -> wlWood,
                    "planks", "wooden_slab", "double_wooden_slab", "crafting_table",
                    "bookshelf", "chest", "trapped_chest");
            group(e, "Leaves", "wlLeaves", () -> wlLeaves,
                    "leaves", "leaves2");
            group(e, "Wool & Carpet", "wlWool", () -> wlWool,
                    "wool", "carpet");
            group(e, "Cobweb", "wlCobweb", () -> wlCobweb,
                    "web");
            group(e, "Metal blocks", "wlMetal", () -> wlMetal,
                    "iron_block", "gold_block", "diamond_block", "emerald_block",
                    "lapis_block", "redstone_block", "coal_block");

            e.text("Extra blocks", "e.g. ender_chest, hay_block", "whitelistExtra");
        });
    }

    /** Adds a check to the whitelist menu and links it to its block names. */
    private void group(ExpandValue e, String label, String configField,
                       final BooleanSupplier state, String... blockNames) {
        e.check(label, configField);
        for (String name : blockNames) {
            BooleanSupplier existing = groupLookup.get(name);
            if (existing == null) {
                groupLookup.put(name, state);
            } else {
                final BooleanSupplier other = existing;
                groupLookup.put(name, new BooleanSupplier() {
                    @Override
                    public boolean getAsBoolean() {
                        return other.getAsBoolean() || state.getAsBoolean();
                    }
                });
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Module lifecycle                                                    */
    /* ------------------------------------------------------------------ */

    @Override
    public void onDisable() {
        restoreSlot();
        clearState();
    }

    @Override
    public void onReset() {
        // Called whenever the world changes
        clearState();
    }

    /* ------------------------------------------------------------------ */
    /* Main logic                                                          */
    /* ------------------------------------------------------------------ */

    @EventTarget
    public void onClientTick(ClientTickEvent event) {
        if (event.getPhase() != ClientTickEvent.Phase.POST) return;
        if (!enabled) return;
        if (mc.thePlayer == null || mc.theWorld == null) {
            clearState();
            return;
        }
        if (mc.currentScreen != null) return;

        final InventoryPlayer inv = mc.thePlayer.inventory;
        final long now = System.currentTimeMillis();

        // The player changed hotbar slot themselves, never fight them over it
        if (originalSlot != -1 && inv.currentItem != swappedSlot) {
            clearState();
        }

        final Block target = getMinedBlock();

        if (target != null) {
            idleSince = 0L;

            final int best = findBestSlot(target);
            if (best == -1) {
                targetSince = 0L;
                return;
            }

            if (targetSince == 0L) targetSince = now;
            if (now - targetSince >= swapDelay) {
                if (originalSlot == -1) originalSlot = inv.currentItem;
                inv.currentItem = best;
                swappedSlot = best;
                targetSince = 0L;
            }
            return;
        }

        // Not mining a valid block right now
        targetSince = 0L;
        if (originalSlot == -1) return;

        if (!swapBack) {
            clearState();
            return;
        }

        if (idleSince == 0L) idleSince = now;
        if (now - idleSince >= swapBackDelay) {
            restoreSlot();
            clearState();
        }
    }

    /**
     * @return the block you are currently mining if every condition passes, otherwise null.
     */
    private Block getMinedBlock() {
        if (!mc.gameSettings.keyBindAttack.isKeyDown()) return null;
        if (mc.thePlayer.isUsingItem()) return null;
        if (!conditionsMet()) return null;

        final MovingObjectPosition mop = mc.objectMouseOver;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return null;

        final BlockPos pos = mop.getBlockPos();
        final Block block = mc.theWorld.getBlockState(pos).getBlock();

        if (block.getMaterial() == Material.air) return null;
        if (block.getBlockHardness(mc.theWorld, pos) < 0.0F) return null; // bedrock etc.
        if (!passesWhitelist(block)) return null;

        return block;
    }

    private boolean conditionsMet() {
        if (mc.thePlayer.capabilities.isCreativeMode) return false; // instant break, nothing to gain

        final boolean sneaking = mc.thePlayer.isSneaking();
        if (SNEAK_ONLY.equals(sneakMode) && !sneaking) return false;
        if (SNEAK_NOT.equals(sneakMode) && sneaking) return false;

        if (onGroundOnly && !mc.thePlayer.onGround) return false;

        return true;
    }

    /* ------------------------------------------------------------------ */
    /* Whitelist                                                           */
    /* ------------------------------------------------------------------ */

    private boolean passesWhitelist(Block block) {
        if (!whitelistEnabled) return true;

        final String name = blockName(block);
        if (name == null) return false;

        final BooleanSupplier group = groupLookup.get(name);
        if (group != null && group.getAsBoolean()) return true;

        return getExtraBlocks().contains(name);
    }

    private String blockName(Block block) {
        try {
            return Block.blockRegistry.getNameForObject(block).getResourcePath();
        } catch (Exception ex) {
            return null;
        }
    }

    /** Parses the "Extra blocks" text, cached until the text changes. */
    private Set<String> getExtraBlocks() {
        final String raw = whitelistExtra == null ? "" : whitelistExtra;
        if (!raw.equals(cachedExtraRaw)) {
            final Set<String> parsed = new HashSet<String>();
            for (String part : raw.toLowerCase().split("[,;\\s]+")) {
                String name = part.trim();
                if (name.startsWith("minecraft:")) name = name.substring("minecraft:".length());
                if (!name.isEmpty()) parsed.add(name);
            }
            cachedExtra = parsed;
            cachedExtraRaw = raw;
        }
        return cachedExtra;
    }

    /* ------------------------------------------------------------------ */
    /* Tool selection                                                      */
    /* ------------------------------------------------------------------ */

    /**
     * @return the hotbar slot holding a better tool for this block than what you hold now,
     * or -1 if you should keep your current slot.
     */
    private int findBestSlot(Block block) {
        final InventoryPlayer inv = mc.thePlayer.inventory;
        final int current = inv.currentItem;

        float bestScore = score(inv.getStackInSlot(current), block);
        int best = -1;

        for (int i = 0; i < 9; i++) {
            if (i == current) continue;

            final ItemStack stack = inv.getStackInSlot(i);
            if (!isAllowedTool(stack)) continue;
            if (stack.getStrVsBlock(block) <= 1.0F) continue; // doesn't actually speed this block up

            final float s = score(stack, block);
            if (s > bestScore + 0.001F) {
                bestScore = s;
                best = i;
            }
        }
        return best;
    }

    /** Only pickaxes, axes, shovels and shears, and only the types enabled in the Tools menu. */
    private boolean isAllowedTool(ItemStack stack) {
        if (stack == null) return false;
        final Item item = stack.getItem();
        if (item instanceof ItemPickaxe) return toolPickaxe;
        if (item instanceof ItemAxe) return toolAxe;
        if (item instanceof ItemSpade) return toolShovel;
        if (item instanceof ItemShears) return toolShears;
        return false;
    }

    /**
     * Higher is better. A tool that can actually harvest the block always beats one that
     * can't (e.g. a fast gold pickaxe on diamond ore), then mining speed (with Efficiency) decides.
     */
    private float score(ItemStack stack, Block block) {
        float speed = 1.0F;
        boolean harvest = block.getMaterial().isToolNotRequired();

        if (stack != null) {
            speed = stack.getStrVsBlock(block);
            if (speed > 1.0F) {
                final int efficiency = EnchantmentHelper.getEnchantmentLevel(Enchantment.efficiency.effectId, stack);
                if (efficiency > 0) speed += efficiency * efficiency + 1;
            }
            if (!harvest) harvest = stack.canHarvestBlock(block);
        }
        return (harvest ? 1000.0F : 0.0F) + speed;
    }

    /* ------------------------------------------------------------------ */
    /* State helpers                                                       */
    /* ------------------------------------------------------------------ */

    private void restoreSlot() {
        if (originalSlot >= 0 && originalSlot < 9 && mc.thePlayer != null
                && mc.thePlayer.inventory.currentItem == swappedSlot) {
            mc.thePlayer.inventory.currentItem = originalSlot;
        }
    }

    private void clearState() {
        originalSlot = -1;
        swappedSlot = -1;
        targetSince = 0L;
        idleSince = 0L;
    }
}
