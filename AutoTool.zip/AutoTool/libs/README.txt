Place your Meowtils jar here and name it "meowtils.jar"
(Download: https://github.com/femboytatp/meowtils/releases)
