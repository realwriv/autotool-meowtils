# AutoTool (Meowtils Extension)

Swaps to the best **tool** in your hotbar while you hold left click on a block.
Only pickaxes, axes, shovels and shears are ever selected (never swords/hoes/other items).

## Settings
| Setting | What it does |
|---|---|
| Swap delay (0-500 ms) | Wait this long after targeting a block before swapping |
| Swap back | Return to the slot you were on after mining |
| Swap back delay (0-1000 ms) | Wait this long after you stop mining before swapping back |
| Sneak | Always / Only sneaking / Not sneaking |
| Only on ground | Skip swapping while airborne |
| Tools menu | Enable/disable Pickaxe, Axe, Shovel, Shears individually |
| Use whitelist | Only swap for blocks you've whitelisted |
| Whitelist menu | Block-group checkboxes + an "Extra blocks" text box (e.g. `ender_chest, hay_block`) |

Notes
- Delays are checked every client tick (50 ms), so 50 ms steps are the real resolution.
- A tool that can actually harvest the block beats a faster one that can't; Efficiency is counted.
- If you change hotbar slot yourself while swapped, AutoTool won't swap back over your choice.
- Does nothing in creative mode, in GUIs, or while eating/using an item.
- Whitelist on + nothing checked = never swaps.

## Build
1. Install JDK 8.
2. Put the Meowtils jar in `libs/` named `meowtils.jar`.
3. `./gradlew build` (or `gradlew.bat build`)
4. Output: `build/libs/AutoTool-1.0.meowtils` -> drop into your `meowtils/extensions` folder (`/extensions` in-game), then `/reload`.
