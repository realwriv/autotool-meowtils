package meowtils.extension;

import wtf.tatp.meowtils.extension.Extension;

/**
 * Entrypoint, called once when the extension is loaded.
 */
public class Main {

    public static void init() {
        Extension.registerModule(new AutoTool());
    }
}
